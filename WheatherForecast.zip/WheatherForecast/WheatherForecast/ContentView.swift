//
//  ContentView.swift
//  WheatherForecast
//
//  Created by Mattia Rizza on 23/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack{
            DayForecast(day: "Mon", isRainy: false, high: 20, low: 10)
            DayForecast(day: "Tue", isRainy: true, high:15, low: 7)
        }
    }
}
        

#Preview {
    ContentView()
}

struct DayForecast: View {
    let day: String
    let isRainy: Bool
    let high: Int
    let low: Int
    
    var iconName: String{
        if isRainy{
            "cloud.rain.fill"
        }
        else{
            "sun.max.fill"
        }
    }
    
    var iconColor: Color{
        if isRainy{
            Color.gray
        }else{
            Color.yellow
        }
    }

    var body: some View {
        VStack {
            Text(day)
                .font(Font.headline) //font parole giorno
            Image(systemName: iconName)
                .foregroundStyle(iconColor)
                .font(Font.largeTitle)
                .padding(5)
            Text("High:\(high)")
                .fontWeight(Font.Weight.semibold)
            Text("Low:\(low)")
                .fontWeight(Font.Weight.medium)
                .foregroundStyle(Color.secondary) //font scritta low
        }
        .padding(30)
    }
}
