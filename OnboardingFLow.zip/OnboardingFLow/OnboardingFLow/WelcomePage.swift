//
//  WelcomePage.swift
//  OnboardingFLow
//
//  Created by Mattia Rizza on 24/10/25.
//

import SwiftUI

struct WelcomePage: View {
    var body: some View {
        VStack {
            ZStack {
                RoundedRectangle(cornerRadius: 30)
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.tint)//tint è il colore di default
                
                Image(systemName: "figure.2.and.child.holdinghands")
                    //.font(.largeTitle)
                    .font(.system(size: 70))
                    .foregroundStyle(.white)
            }
            
            Text("Welcome to my App")
                .font(.title)
                .padding(.top)//qui metti lo spazio solo sopra il titolo
                .fontWeight(.semibold) //frase in grassetto
                //.border(.black, width: 1.5)
            
            Text("Description Text")
                .font(.title)
                //.multilineTextAlignment(.trailing) allineamento frase
                //.border(.black, width: 1.5)
        }
       //.border(.orange, width: 1.5)
        .padding()
        //.border(.purple, width: 1.5)
    }
}

#Preview {
    WelcomePage()
}
