//
//  ContentView.swift
//  OnboardingFLow
//
//  Created by Mattia Rizza on 24/10/25.
//

import SwiftUI

let gradientColors: [Color] = [ //per avere il colore così sfumato
    .gradientTop,
    .gradientBottom
]

struct ContentView: View {
    var body: some View {
        VStack {
            TabView{
                WelcomePage()
                FeaturesPage()
            }
            .background(Gradient(colors: gradientColors)) //per avere il colore
            .tabViewStyle(.page)
            .foregroundStyle(.white) //colore bianco alle scritte
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
