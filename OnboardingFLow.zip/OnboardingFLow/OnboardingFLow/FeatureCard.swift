//
//  FeatureCard.swift
//  OnboardingFLow
//
//  Created by Mattia Rizza on 24/10/25.
//

import SwiftUI

struct FeatureCard: View {
    let iconName : String
    let description : String
    
    var body: some View {
        HStack{
            Image(systemName: iconName)
                .font(.largeTitle)
                .frame(width: 50)
                .padding(.trailing, 10)
            
            Text(description)
            
            Spacer()//espande il più possibile per riempire lo spazio vuoto nella direzione della pila che li contiene
           
        }
        .padding()
        //.background(.tint, in: RoundedRectangle(cornerRadius: 12))
        //.foregroundStyle(.white)
        background{
            RoundedRectangle(cornerRadius: 12)
                .foregroundStyle(.tint)
        }
    }
}

#Preview {
    FeatureCard(iconName: "person.2.crop.square.stack.fill",
                description: "Una descrizione su più righe di una caratteristica abbinata all'immagine a sinistra.")
}
