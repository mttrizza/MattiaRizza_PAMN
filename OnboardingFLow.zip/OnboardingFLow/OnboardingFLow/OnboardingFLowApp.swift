//
//  OnboardingFLowApp.swift
//  OnboardingFLow
//
//  Created by Mattia Rizza on 24/10/25.
//

import SwiftUI

@main
struct OnboardingFLowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
