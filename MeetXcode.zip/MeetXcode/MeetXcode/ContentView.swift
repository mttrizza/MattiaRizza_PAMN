//
//  ContentView.swift
//  MeetXcode
//
//  Created by Mattia Rizza on 22/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Toc, toc")
                .padding() //aggiunge spazio extra
                .background(Color.blue, in: RoundedRectangle(cornerRadius: 8))
            Text("Chi è?")
                .padding()
                .background(Color.yellow, in:
                RoundedRectangle(cornerRadius: 8))
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
