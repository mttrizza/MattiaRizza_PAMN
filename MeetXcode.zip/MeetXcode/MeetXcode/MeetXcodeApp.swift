//
//  MeetXcodeApp.swift
//  MeetXcode
//
//  Created by Mattia Rizza on 22/10/25.
//

import SwiftUI

@main
struct MeetXcodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
